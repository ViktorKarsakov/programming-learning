package kkkvd.operator.operatorkvd.entities;

public interface NamedDictionary {
    Long getId();
    String getName();
}
