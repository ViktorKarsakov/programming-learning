package kkkvd.operator.operatorkvd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OperatorKvdApplicationTests {

    @Test
    void contextLoads() {
    }

}
