package kkkvd.operator.operatorkvd.repositories;

import kkkvd.operator.operatorkvd.entities.Inspection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InspectionRepository extends JpaRepository<Inspection, Long> {
}
