package kkkvd.operator.operatorkvd.dto.dict;

import lombok.Data;

@Data
public class StateRequest {
    private String name;
    private Long stateGroupId;
}
