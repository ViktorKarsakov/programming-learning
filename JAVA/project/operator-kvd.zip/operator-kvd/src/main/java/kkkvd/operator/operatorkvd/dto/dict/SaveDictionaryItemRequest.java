package kkkvd.operator.operatorkvd.dto.dict;

import lombok.Data;

@Data
public class SaveDictionaryItemRequest {
    private String name;
}
