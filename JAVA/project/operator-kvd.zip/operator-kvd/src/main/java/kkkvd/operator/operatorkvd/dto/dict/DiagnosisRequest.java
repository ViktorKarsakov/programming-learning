package kkkvd.operator.operatorkvd.dto.dict;

import lombok.Data;

@Data
public class DiagnosisRequest {
    private String name;
    private Long diagnosisGroupId;
}
