package kkkvd.operator.operatorkvd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OperatorKvdApplication {

    public static void main(String[] args) {
        SpringApplication.run(OperatorKvdApplication.class, args);
    }

}
